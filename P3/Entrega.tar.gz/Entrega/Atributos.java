/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author REYES ALBILLAR, ALEJANDRO <ara65@alu.ua.es>
 * <el_reyes_95@hotmmail.com> <el.reyes.95@gmail.com>
 */
public class Atributos {
    public String tipo;
    public String trad;
    
    Atributos(String tipo, String trad){
        this.tipo=tipo;
        this.trad=trad;
    }
}
